F2F Streets Offline 2.11 – dieselbe aktualisierte Tonalität wie die Online-Version. Keine zentrale E-Mail-Erfassung.

F2F STREETS OFFLINE-SPIEL

ZIP entpacken und index.html öffnen.
Dieses kompakte Paket enthält die spielbare Kartenbibliothek und die Charakterbilder.
Die druckbaren Materialien und der neue Downloadshop liegen im separaten Webpaket 2.10.
